# im-todo
A demo application used to learn JavaScrip in Winter 2019.
An ongoing project been developmed during IMM classes.

February 22, 2018 - Lab
Create an HTML project.

Develop an interface to match the criteria for your "todo list".

Write the data object to hold at least five tasks, in various states (depending on what's applicable to your project, but if applicable: different levels of completion, different categories, etc). Consider all of the data that would be required to make this application efficient (sorting criteria, set/unset completion status, etc).

Use the data object and write the appropriate Javascript to populate the HTML dynamically. For this, just show all of the items in their various states (use classes to modify styling where applicable), no need to do any specific filtering functionality yet.

Update your Github repo before the deadline and submit a link to it through your comments/submission on Blackboard. Also attach a zip if your project to this submission.
